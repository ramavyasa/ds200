import pandas as pd
import matplotlib.pyplot as plt
import sys

df=pd.read_csv("bar.csv", header=None, names=['Number'])

ax = df[['Number']].plot(kind='bar', title ="Number of cattles in each district of Karnataka", figsize=(15, 10), legend=True, fontsize=12)

ax.set_xlabel("District", fontsize=12)
ax.set_ylabel("Number of Cattles", fontsize=12)
plt.show()